import React, { useEffect, useMemo, useState } from "react";
import { Download, Upload, Trash2, Edit3, Save, X, PlusCircle, BarChart3, Settings, BookOpenCheck, Search, FileSpreadsheet, Gauge, HelpCircle, ChevronRight, ChevronDown } from "lucide-react";

const STORAGE_KEY = "dj_pro_v3";

const DEFAULT_CONVERTERS = [
  { unit: "Hours", type: "Time", baseUnit: "Hours", factorToBase: 1 },
  { unit: "Minutes", type: "Time", baseUnit: "Hours", factorToBase: 1 / 60 },
  { unit: "Seconds", type: "Time", baseUnit: "Hours", factorToBase: 1 / 3600 },
  { unit: "Km", type: "Distance", baseUnit: "Km", factorToBase: 1 },
  { unit: "Meters", type: "Distance", baseUnit: "Km", factorToBase: 0.001 },
  { unit: "Miles", type: "Distance", baseUnit: "Km", factorToBase: 1.60934 },
  { unit: "Times", type: "Count", baseUnit: "Times", factorToBase: 1 },
  { unit: "Liters", type: "Volume", baseUnit: "Liters", factorToBase: 1 },
  { unit: "Ml", type: "Volume", baseUnit: "Liters", factorToBase: 0.001 },
];

const DEFAULT_CATEGORIES = [
  { name: "Work", type: "Time", displayUnit: "Auto" },
  { name: "Running", type: "Distance", displayUnit: "Auto" },
  { name: "Reading", type: "Time", displayUnit: "Auto" },
  { name: "Study", type: "Time", displayUnit: "Auto" },
  { name: "Chores", type: "Count", displayUnit: "Auto" },
  { name: "Hobby", type: "Time", displayUnit: "Auto" },
  { name: "Sleep", type: "Time", displayUnit: "Auto" },
  { name: "Bed", type: "Count", displayUnit: "Auto" },
  { name: "Other", type: "Time", displayUnit: "Auto" },
];

const TYPE_BASE = { Time: "Hours", Distance: "Km", Count: "Times", Volume: "Liters" };
const TYPES = Object.keys(TYPE_BASE);

function startOfMonth(d = new Date()) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d = new Date()) { return new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999); }
function fmtDateISO(d) { const dt = new Date(d); return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,"0")}-${String(dt.getDate()).padStart(2,"0")}`; }
function uid() { return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`; }
function round(n, dp = 2) { const p = 10**dp; return Math.round((n + Number.EPSILON) * p) / p; }
function humanizeTime(hours) { if (hours==null||isNaN(hours)) return ""; const totalMin = Math.round(hours*60); const h=Math.floor(totalMin/60), m=totalMin%60; return h===0?`${m} min`:`${h} h ${m} min`; }
function humanizeDistance(km) { if (km==null||isNaN(km)) return ""; const totalM = Math.round(km*1000); const k=Math.floor(totalM/1000), m=totalM%1000; return k===0?`${m} m`:`${k} km ${m} m`; }

const UNIT_SHORT = { Hours:'h', Minutes:'min', Seconds:'s', Km:'km', Meters:'m', Miles:'mi', Times:'×', Liters:'L', Ml:'ml' };
function getFactor(converters, type, unit){ const c = converters.find(c=> c.type===type && c.unit===unit); return c? c.factorToBase : 1; }
function formatSingleUnit(type, valueInBase, unit, converters){
  const factor = getFactor(converters, type, unit) || 1;
  const amount = valueInBase / factor;
  const label = UNIT_SHORT[unit] || unit;
  if(type==='Time') return `${Math.round(amount)} ${label}`;
  if(type==='Distance') return `${Math.round(amount)} ${label}`;
  if(type==='Count') return `${Math.round(amount)}${label==='×'?'×':''}`;
  if(type==='Volume') return `${Math.round(amount*100)/100} ${label}`;
  return `${amount} ${label}`;
}

const UNIT_SYNONYMS = {
  Time: { h: "Hours", hr: "Hours", hrs: "Hours", hour: "Hours", hours: "Hours", m: "Minutes", min: "Minutes", mins: "Minutes", minute: "Minutes", minutes: "Minutes", s: "Seconds", sec: "Seconds", secs: "Seconds", second: "Seconds", seconds: "Seconds" },
  Distance: { km: "Km", kilometer: "Km", kilometers: "Km", kilometre: "Km", kilometres: "Km", m: "Meters", meter: "Meters", meters: "Meters", metre: "Meters", metres: "Meters", mi: "Miles", mile: "Miles", miles: "Miles" },
  Volume: { l: "Liters", liter: "Liters", litre: "Liters", liters: "Liters", litres: "Liters", ml: "Ml", milliliter: "Ml", millilitre: "Ml", milliliters: "Ml", millilitres: "Ml" },
  Count: { x: "Times", time: "Times", times: "Times" },
};

function toNumber(s){ if(s==null) return NaN; const t=String(s).trim().replace(/,/g,'.'); const n=parseFloat(t); return Number.isFinite(n)? n : NaN; }

function tokenizeAmount(str){
  const tokens = []; let cur=""; let mode=null;
  const push=(type,val)=>{ if(val!=="" && val!=null) tokens.push({type, val: String(val)}); };
  for(let i=0;i<str.length;i++){
    const ch=str[i];
    const isDigit = (ch>='0' && ch<='9') || ch==='.' || ch===',';
    const isLetter = /[a-zA-ZåäöÅÄÖ]/.test(ch);
    if(isDigit){ if(mode!=='num'){ push(mode,cur); cur=""; mode='num'; } cur+=ch; }
    else if(isLetter){ if(mode!=='word'){ push(mode,cur); cur=""; mode='word'; } cur+=ch; }
    else if(ch===':' ){ push(mode,cur); cur=":"; push('colon',cur); cur=""; mode=null; }
    else { push(mode,cur); cur=""; mode=null; }
  }
  push(mode,cur);
  return tokens.filter(t=>t && t.val!=='');
}

function parseAmountByType(input, type, converters){
  if(!input || !String(input).trim()) return null;
  const str = String(input).trim().toLowerCase();
  if(type==='Time') return parseTimeAmount(str);
  if(type==='Distance') return parseDistanceAmount(str, converters);
  if(type==='Count') return parseCountAmount(str);
  if(type==='Volume') return parseVolumeAmount(str, converters);
  return null;
}

function parseTimeAmount(str){
  if(str.includes(':')){
    const parts=str.split(':').map(p=>toNumber(p));
    if(parts.length>=2 && Number.isFinite(parts[0]) && Number.isFinite(parts[1])){
      const h=parts[0]||0, m=parts[1]||0, s=(parts[2]||0);
      return { value: h + m/60 + s/3600, unit: 'Hours' };
    }
  }
  const tokens = tokenizeAmount(str);
  let hours=0, minutes=0, seconds=0; let matched=false;
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i];
    if(t.type==='num'){
      const num = toNumber(t.val); if(!Number.isFinite(num)) continue;
      const nxt = tokens[i+1];
      if(nxt && nxt.type==='word'){
        const canon = UNIT_SYNONYMS.Time[nxt.val] || null;
        if(canon==='Hours'){ hours+=num; matched=true; i++; continue; }
        if(canon==='Minutes'){ minutes+=num; matched=true; i++; continue; }
        if(canon==='Seconds'){ seconds+=num; matched=true; i++; continue; }
      } else { minutes+=num; matched=true; }
    }
  }
  if(!matched) return null;
  return { value: hours + minutes/60 + seconds/3600, unit: 'Hours' };
}

function parseDistanceAmount(str, converters){
  const tokens = tokenizeAmount(str); let km=0; let matched=false;
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i]; if(t.type!=='num') continue; const num=toNumber(t.val); if(!Number.isFinite(num)) continue;
    const nxt=tokens[i+1];
    if(nxt && nxt.type==='word'){
      const canon = UNIT_SYNONYMS.Distance[nxt.val] || null;
      if(canon){ km += num * getFactor(converters,'Distance',canon); matched=true; i++; continue; }
    }
    km += num * getFactor(converters,'Distance','Meters'); matched=true;
  }
  if(!matched) return null; return { value: km, unit: 'Km' };
}

function parseVolumeAmount(str, converters){
  const tokens = tokenizeAmount(str); let liters=0; let matched=false;
  for(let i=0;i<tokens.length;i++){
    const t=tokens[i]; if(t.type!=='num') continue; const num=toNumber(t.val); if(!Number.isFinite(num)) continue;
    const nxt=tokens[i+1];
    if(nxt && nxt.type==='word'){
      const canon = UNIT_SYNONYMS.Volume[nxt.val] || null;
      if(canon){ liters += num * getFactor(converters,'Volume',canon); matched=true; i++; continue; }
    }
    liters += num * getFactor(converters,'Volume','Ml'); matched=true;
  }
  if(!matched) return null; return { value: liters, unit: 'Liters' };
}

function parseCountAmount(str){
  const tokens = tokenizeAmount(str); for(let i=0;i<tokens.length;i++){ const t=tokens[i]; if(t.type==='num'){ const n=parseInt(t.val.replace(',','.'),10); if(Number.isFinite(n)) return { value:n, unit:'Times' }; } }
  return null;
}

function amountPlaceholderByType(type){
  if(type==='Time') return "e.g., 1h 46m, 90min, 1:46, 3600s";
  if(type==='Distance') return "e.g., 3km 250m, 5935m, 2.1mi";
  if(type==='Count') return "e.g., 1, 12x, 3 times";
  if(type==='Volume') return "e.g., 500ml, 1.5l";
  return "e.g., 1h 30m";
}

function runDevTests(){
  const approx = (a,b,e=1e-6)=> Math.abs(a-b) <= e;
  const tests = [];
  const t1 = parseAmountByType('1h 46m','Time',DEFAULT_CONVERTERS); tests.push( approx(t1.value, 1 + 46/60) && t1.unit==='Hours' );
  const t2 = parseAmountByType('90min','Time',DEFAULT_CONVERTERS); tests.push( approx(t2.value, 1.5) );
  const t3 = parseAmountByType('1:46','Time',DEFAULT_CONVERTERS); tests.push( approx(t3.value, 1 + 46/60) );
  const t4 = parseAmountByType('1h 2m 30s','Time',DEFAULT_CONVERTERS); tests.push( approx(t4.value, 1 + 2/60 + 30/3600) );
  const t5 = parseAmountByType('75','Time',DEFAULT_CONVERTERS); tests.push( approx(t5.value, 1.25) );
  const t6 = parseAmountByType(' 2 HOURS  ','Time',DEFAULT_CONVERTERS); tests.push( approx(t6.value, 2) );
  const d1 = parseAmountByType('5935m','Distance',DEFAULT_CONVERTERS); tests.push( approx(d1.value, 5.935) );
  const d2 = parseAmountByType('3km 250m','Distance',DEFAULT_CONVERTERS); tests.push( approx(d2.value, 3.25) );
  const d3 = parseAmountByType('1 mile','Distance',DEFAULT_CONVERTERS); tests.push( approx(d3.value, 1.60934) );
  const c1 = parseAmountByType('12x','Count',DEFAULT_CONVERTERS); tests.push( c1.value===12 && c1.unit==='Times' );
  const c2 = parseAmountByType('3 times','Count',DEFAULT_CONVERTERS); tests.push( c2.value===3 );
  const v1 = parseAmountByType('500ml','Volume',DEFAULT_CONVERTERS); tests.push( approx(v1.value, 0.5) );
  const v2 = parseAmountByType('1.25l','Volume',DEFAULT_CONVERTERS); tests.push( approx(v2.value, 1.25) );
  const out1 = formatSingleUnit('Distance', 5.935, 'Meters', DEFAULT_CONVERTERS); tests.push(out1.includes('5935'));
  const out2 = formatSingleUnit('Time', 1.5, 'Minutes', DEFAULT_CONVERTERS); tests.push(out2.includes('90'));
  const out3 = formatSingleUnit('Volume', 1.5, 'Ml', DEFAULT_CONVERTERS); tests.push(out3.includes('1500'));
  const twoH = 120 * getFactor(DEFAULT_CONVERTERS, 'Time', 'Minutes'); tests.push(approx(twoH, 2));
  const out4 = formatSingleUnit('Count', 12, 'Times', DEFAULT_CONVERTERS); tests.push(out4.includes('12'));
  const passed = tests.every(Boolean);
  console[passed? 'log':'error'](`DEV TESTS: ${passed? 'all passed':'some failed'} ->`, tests);
}

export default function App(){
  const [entries, setEntries] = useState([]);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [converters, setConverters] = useState(DEFAULT_CONVERTERS);
  const [month, setMonth] = useState(fmtDateISO(startOfMonth()));
  const [q, setQ] = useState("");
  const [filterCat, setFilterCat] = useState("ALL");
  const [tab, setTab] = useState("log");
  const [editingId, setEditingId] = useState(null);

  useEffect(()=>{ runDevTests(); },[]);

  useEffect(()=>{
    try{
      const raw = localStorage.getItem(STORAGE_KEY);
      if(raw){
        const p = JSON.parse(raw);
        if(p.entries) setEntries(p.entries);
        if(p.converters) setConverters(p.converters);
        if(p.month) setMonth(p.month);
        if(p.categories){
          if(Array.isArray(p.categories) && typeof p.categories[0] === 'string') setCategories(p.categories.map(n=>({name:n, type:'Time', displayUnit:'Auto'})));
          else setCategories(p.categories);
        }
        return;
      }
      const legacy = localStorage.getItem("dj_pro_v2") || localStorage.getItem("dj_pro_v1");
      if(legacy){
        const p = JSON.parse(legacy);
        if(p.entries) setEntries(p.entries);
        if(p.converters) setConverters(p.converters);
        if(p.month) setMonth(p.month);
        if(p.categories){ if(Array.isArray(p.categories) && typeof p.categories[0] === 'string') setCategories(p.categories.map(n=>({name:n, type:'Time', displayUnit:'Auto'}))); else setCategories(p.categories); }
      }
    }catch(e){ console.warn('load failed', e); }
  },[]);

  useEffect(()=>{ localStorage.setItem(STORAGE_KEY, JSON.stringify({ entries, categories, converters, month })); }, [entries, categories, converters, month]);

  const monthStart = useMemo(()=> new Date(month+"T00:00:00"),[month]);
  const monthEnd = useMemo(()=> endOfMonth(monthStart),[monthStart]);
  const catTypeMap = useMemo(()=>{ const m=new Map(); categories.forEach(c=>m.set(c.name, c.type)); return m; },[categories]);
  const catMetaMap = useMemo(()=>{ const m=new Map(); categories.forEach(c=>m.set(c.name, c)); return m; },[categories]);

  const entriesThisMonth = useMemo(()=> entries.filter(e=>{ const d=new Date(e.date+"T00:00:00"); return d>=monthStart && d<=monthEnd; }), [entries, monthStart, monthEnd]);

  const searched = useMemo(()=>{
    const needle=q.trim().toLowerCase();
    return entriesThisMonth.filter(e=>{
      if(filterCat!=="ALL" && e.category!==filterCat) return false;
      if(!needle) return true; const notes=(e.notes||"").toLowerCase();
      return e.category.toLowerCase().includes(needle)||e.unit.toLowerCase().includes(needle)||String(e.value).toLowerCase().includes(needle)||notes.includes(needle);
    });
  },[entriesThisMonth, q, filterCat]);

  const convByUnit = useMemo(()=>{ const m=new Map(); converters.forEach(c=>m.set(c.unit,c)); return m; },[converters]);

  const entriesByCategory = useMemo(()=>{
    const map = {};
    for(const e of entriesThisMonth){ (map[e.category] ||= []).push(e); }
    return map;
  }, [entriesThisMonth]);

  const totalsByCatBase = useMemo(()=>{ const m={}; for(const e of entriesThisMonth){ const conv = convByUnit.get(e.unit); if(!conv) continue; const base = conv.baseUnit; const k=`${e.category}__${base}`; m[k]=(m[k]||0)+(Number(e.value)||0)*(conv.factorToBase||0);} return m; },[entriesThisMonth, convByUnit]);

  const categoriesUsed = useMemo(()=> Array.from(new Set([...(categories?.map(c=>c.name)||[]), ...entriesThisMonth.map(e=>e.category)])), [categories, entriesThisMonth]);

  const totalsByCategoryReadable = useMemo(()=>{
    const out = {};
    for(const name of categoriesUsed){
      const meta = catMetaMap.get(name) || { type:'Time', displayUnit:'Auto' };
      const type = meta.type || 'Time';
      const base = TYPE_BASE[type];
      const key = `${name}__${base}`;
      const v = totalsByCatBase[key] || 0;
      let str = '';
      if(meta.displayUnit && meta.displayUnit !== 'Auto'){
        str = formatSingleUnit(type, v, meta.displayUnit, converters);
      } else {
        if(type==='Time') str = humanizeTime(v);
        else if(type==='Distance') str = humanizeDistance(v);
        else if(type==='Count') str = `${round(v,0)}`;
        else if(type==='Volume') str = `${round(v,2)} L`;
      }
      out[name] = { type, base, value: v, display: str };
    }
    return out;
  }, [categoriesUsed, totalsByCatBase, catMetaMap, converters]);

  const totalHours = useMemo(()=> Object.entries(totalsByCatBase).filter(([k])=>k.endsWith("__Hours")).reduce((a,[,v])=>a+v,0), [totalsByCatBase]);
  const totalKm = useMemo(()=> Object.entries(totalsByCatBase).filter(([k])=>k.endsWith("__Km")).reduce((a,[,v])=>a+v,0), [totalsByCatBase]);
  const totalTimes = useMemo(()=> Object.entries(totalsByCatBase).filter(([k])=>k.endsWith("__Times")).reduce((a,[,v])=>a+v,0), [totalsByCatBase]);
  const totalLiters = useMemo(()=> Object.entries(totalsByCatBase).filter(([k])=>k.endsWith("__Liters")).reduce((a,[,v])=>a+v,0), [totalsByCatBase]);

  function addEntry(partial){
    const catType = catTypeMap.get(partial.category) || 'Time';
    let value = Number(partial.value||0), unit = partial.unit || TYPE_BASE[catType];
    if(partial.amount){
      const parsed = parseAmountByType(partial.amount, catType, converters);
      if(!parsed){ alert("Could not understand the amount. Try formats like: " + amountPlaceholderByType(catType)); return; }
      value = parsed.value; unit = parsed.unit;
    }
    const e={ id: uid(), date: partial.date||fmtDateISO(new Date()), category: partial.category, value, unit, notes: partial.notes||"" };
    setEntries(prev=>[e,...prev]);
  }
  function updateEntry(id, patch){ setEntries(prev=>prev.map(e=> e.id===id? { ...e, ...patch, value: Number(patch.value ?? e.value) }: e)); }
  function removeEntry(id){ setEntries(prev=> prev.filter(e=>e.id!==id)); }

  function addCategory(name, type){ const n=name.trim(); if(!n) return; if(categories.some(c=>c.name===n)) return; setCategories(prev=>[...prev,{name:n, type:type||'Time', displayUnit:'Auto'}]); }
  function setCategoryType(name, type){ setCategories(prev=> prev.map(c=> c.name===name? {...c, type}: c)); }
  function removeCategory(name){ setCategories(prev=> prev.filter(c=> c.name!==name)); }

  async function exportJSON(){ const payload={entries,categories,converters}; const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`daily_journal_backup_${fmtDateISO(new Date())}.json`; a.click(); URL.revokeObjectURL(url); }
  async function importJSON(file){ const text=await file.text(); const data=JSON.parse(text); if(data.entries) setEntries(data.entries); if(data.converters) setConverters(data.converters); if(data.categories){ if(typeof data.categories[0]==='string') setCategories(data.categories.map(n=>({name:n, type:'Time', displayUnit:'Auto'}))); else setCategories(data.categories);} }

  async function importExcel(file){ const XLSX=(await import('xlsx')).default; const data=await file.arrayBuffer(); const wb=XLSX.read(data,{cellDates:true});
    if(wb.Sheets['Log']){ const rows=XLSX.utils.sheet_to_json(wb.Sheets['Log'],{defval:""}); const newEntries=[]; for(const r of rows){ const d = r.Date instanceof Date? r.Date : new Date(r.Date); if(!d||isNaN(+d)) continue; newEntries.push({ id: uid(), date: fmtDateISO(d), category: String(r.Category||'Other'), value: Number(r.Value||0), unit: String(r.Unit||'Hours'), notes: String(r.Notes||'') }); } if(newEntries.length) setEntries(prev=>[...newEntries,...prev]); }
    if(wb.Sheets['Converters']){ const rows=XLSX.utils.sheet_to_json(wb.Sheets['Converters'],{defval:""}); const parsed=[]; for(const r of rows){ if(!r.Unit) continue; parsed.push({ unit:String(r.Unit), type:String(r.Type||''), baseUnit:String(r['BaseUnit (of Type)']||r.BaseUnit||''), factorToBase:Number(r.FactorToBase||0) }); } if(parsed.length) setConverters(parsed); }
    if(wb.Sheets['Categories']){ const rows=XLSX.utils.sheet_to_json(wb.Sheets['Categories'],{defval:""}); const cats=[]; for(const r of rows){ if(!r.Name) continue; cats.push({ name:String(r.Name), type:String(r.Type||'Time'), displayUnit:'Auto' }); } if(cats.length) setCategories(cats); }
  }

  async function exportExcel(){ const XLSX=(await import('xlsx')).default; const wb=XLSX.utils.book_new(); const logRows=[["Date","Category","Value","Unit","Notes"], ...entries.map(e=>[e.date,e.category,e.value,e.unit,e.notes])]; const wsLog=XLSX.utils.aoa_to_sheet(logRows); XLSX.utils.book_append_sheet(wb, wsLog, 'Log'); const convRows=[["Unit","Type","BaseUnit (of Type)","FactorToBase"], ...converters.map(c=>[c.unit,c.type,c.baseUnit,c.factorToBase])]; const wsConv=XLSX.utils.aoa_to_sheet(convRows); XLSX.utils.book_append_sheet(wb, wsConv, 'Converters'); const catRows=[["Name","Type","DisplayUnit"], ...categories.map(c=>[c.name,c.type,c.displayUnit||'Auto'])]; const wsCats=XLSX.utils.aoa_to_sheet(catRows); XLSX.utils.book_append_sheet(wb, wsCats, 'Categories'); XLSX.writeFile(wb, `daily_journal_export_${fmtDateISO(new Date())}.xlsx`); }

  const unitsByType = useMemo(()=>{ const m={}; TYPES.forEach(t=> m[t]=converters.filter(c=>c.type===t).map(c=>c.unit)); return m; },[converters]);
  const categoriesNames = categories.map(c=>c.name);

  const [newEntry, setNewEntry] = useState({ date: fmtDateISO(new Date()), category: DEFAULT_CATEGORIES[0].name, amount: "", notes: "" });
  const newEntryType = (catTypeMap.get(newEntry.category) || 'Time');

  const entriesCount = entriesThisMonth.length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-900">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <BookOpenCheck className="w-6 h-6" />
          <h1 className="text-xl font-semibold">Daily Journal — Time & Activity Tracker</h1>
          <div className="ml-auto flex items-center gap-3">
            <input type="month" className="input w-[160px]" value={month.slice(0,7)} onChange={(e)=>setMonth(e.target.value+"-01")} />
            <button className={`tab ${tab==='log'?'tab-active':''}`} onClick={()=>setTab('log')}>Log</button>
            <button className={`tab ${tab==='dash'?'tab-active':''}`} onClick={()=>setTab('dash')}><BarChart3 className="w-4 h-4 mr-1"/>Dashboard</button>
            <button className={`tab ${tab==='settings'?'tab-active':''}`} onClick={()=>setTab('settings')}><Settings className="w-4 h-4 mr-1"/>Settings</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <MetricCard title="Entries" value={entriesCount} />
          <MetricCard title="Time" value={humanizeTime(totalHours)} />
          <MetricCard title="Distance" value={humanizeDistance(totalKm)} />
          <MetricCard title="Times" value={round(totalTimes,0)} />
        </section>

        {tab==='log' && (
          <>
            <section className="bg-white shadow-sm rounded-2xl p-4 border border-slate-200">
              <h2 className="text-lg font-semibold mb-3 flex items-center"><PlusCircle className="w-4 h-4 mr-2"/>Quick add</h2>
              <div className="grid md:grid-cols-6 gap-3">
                <input type="date" className="input" value={newEntry.date} onChange={e=>setNewEntry({...newEntry, date:e.target.value})} />
                <select className="input" value={newEntry.category} onChange={e=>setNewEntry({...newEntry, category:e.target.value})}>
                  {categoriesNames.map(c=> <option key={c} value={c}>{c}</option>)}
                </select>
                <input className="input md:col-span-2" placeholder={amountPlaceholderByType(newEntryType)} value={newEntry.amount} onChange={e=>setNewEntry({...newEntry, amount:e.target.value})} />
                <input className="input md:col-span-2" placeholder="Notes (optional)" value={newEntry.notes} onChange={e=>setNewEntry({...newEntry, notes:e.target.value})} />
              </div>
              <div className="mt-2 text-xs text-slate-500 flex items-center gap-2"><HelpCircle className="w-3 h-3"/>Examples — Time: "1h 46m", "90min", "1:46" · Distance: "3km 250m", "5935m", "2mi"</div>
              <div className="mt-3 flex gap-2">
                <button className="btn btn-primary" onClick={()=> (addEntry(newEntry), setNewEntry({...newEntry, amount:"", notes:""}))}><PlusCircle className="w-4 h-4 mr-1"/>Add entry</button>
              </div>
            </section>

            <section className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
              <div className="flex items-center gap-2 bg-white rounded-2xl px-3 py-2 border border-slate-200 shadow-sm">
                <Search className="w-4 h-4"/>
                <input className="outline-none" placeholder="Search" value={q} onChange={e=>setQ(e.target.value)} />
              </div>
              <select className="input w-full md:w-[240px]" value={filterCat} onChange={e=>setFilterCat(e.target.value)}>
                <option value="ALL">All categories</option>
                {categoriesNames.map(c=> <option key={c}>{c}</option>)}
              </select>
              <div className="ml-auto flex gap-2">
                <label className="btn"><Upload className="w-4 h-4 mr-1"/>Import JSON<input type="file" accept="application/json" className="hidden" onChange={e=> e.target.files?.[0] && importJSON(e.target.files[0])} /></label>
                <label className="btn"><Upload className="w-4 h-4 mr-1"/>Import Excel<input type="file" accept=".xlsx,.xls" className="hidden" onChange={e=> e.target.files?.[0] && importExcel(e.target.files[0])} /></label>
                <button className="btn" onClick={exportJSON}><Download className="w-4 h-4 mr-1"/>Export JSON</button>
                <button className="btn" onClick={exportExcel}><FileSpreadsheet className="w-4 h-4 mr-1"/>Export Excel</button>
              </div>
            </section>

            <section className="bg-white shadow-sm rounded-2xl border border-slate-200 overflow-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50/70"><tr className="text-left">
                  <th className="p-2">Date</th><th className="p-2">Category</th><th className="p-2">Value</th><th className="p-2">Unit</th><th className="p-2">Notes</th><th className="p-2 text-right">Actions</th>
                </tr></thead>
                <tbody>
                  {searched.slice().sort((a,b)=> a.date<b.date?1:-1).map(e=> (
                    <EntryRow key={e.id} e={e} categories={categories} converters={converters} catTypeMap={catTypeMap} unitsByType={unitsByType} updateEntry={updateEntry} removeEntry={removeEntry} editingId={editingId} setEditingId={setEditingId}/>
                  ))}
                </tbody>
              </table>
            </section>
          </>
        )}

        {tab==='dash' && (
          <>
            <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {categoriesNames.map(name=>{
                const t = catTypeMap.get(name)||'Time';
                const info = totalsByCategoryReadable[name] || { type:t, display:'—' };
                return <TrackerCard key={name} name={name} type={t} display={info.display} />;
              })}
            </section>

            <section className="bg-white shadow-sm rounded-2xl p-4 border border-slate-200">
              <h2 className="text-lg font-semibold mb-3">Totals this month</h2>
              <CategoryTotalsTable
                categories={categories}
                totalsByCategoryReadable={totalsByCategoryReadable}
                entriesByCategory={entriesByCategory}
                converters={converters}
              />
            </section>
          </>
        )}

        {tab==='settings' && (
          <div className="grid lg:grid-cols-2 gap-6">
            <section className="bg-white shadow-sm rounded-2xl p-4 border border-slate-200">
              <h2 className="text-lg font-semibold mb-3">Categories (type‑locked)</h2>
              <CategoryManager categories={categories} setCategories={setCategories} onAdd={addCategory} onSetType={setCategoryType} onRemove={removeCategory} converters={converters} />
            </section>
            <section className="bg-white shadow-sm rounded-2xl p-4 border border-slate-200">
              <h2 className="text-lg font-semibold mb-3">Units & Converters</h2>
              <ConverterManager converters={converters} setConverters={setConverters}/>
            </section>
          </div>
        )}
      </main>

      <footer className="py-8 text-center text-xs text-slate-500">Your data stays in your browser (localStorage). Export regularly for backups.</footer>
    </div>
  );
}

function MetricCard({ title, value }){ return (<div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200"><div className="text-xs uppercase tracking-wide text-slate-500">{title}</div><div className="mt-1 text-xl font-semibold">{String(value||"—")}</div></div>); }

function TrackerCard({ name, type, display }){
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex items-center gap-3">
      <Gauge className="w-5 h-5"/>
      <div className="flex-1">
        <div className="text-sm text-slate-500">{name}</div>
        <div className="text-lg font-semibold">{display || '—'}</div>
        <div className="text-xs text-slate-400 mt-1">{type}</div>
      </div>
    </div>
  );
}

function CategoryTotalsTable({ categories, totalsByCategoryReadable, entriesByCategory, converters }){
  const [open, setOpen] = useState(null);
  const catMetaMap = useMemo(()=>{ const m=new Map(); categories.forEach(c=>m.set(c.name, c)); return m; }, [categories]);

  const categoryRows = useMemo(()=> Object.keys(entriesByCategory).sort((a,b)=> a.localeCompare(b)), [entriesByCategory]);

  function formatForCategory(meta, baseVal){
    const type = meta.type || 'Time';
    if(meta.displayUnit && meta.displayUnit !== 'Auto') return formatSingleUnit(type, baseVal, meta.displayUnit, converters);
    if(type==='Time') return humanizeTime(baseVal);
    if(type==='Distance') return humanizeDistance(baseVal);
    if(type==='Count') return String(round(baseVal,0));
    if(type==='Volume') return `${round(baseVal,2)} L`;
    return String(baseVal);
  }

  function entryBaseValue(e){
    const conv = converters.find(c=> c.unit===e.unit);
    const factor = conv? conv.factorToBase : 1;
    return (Number(e.value)||0) * factor;
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200">
      <table className="w-full text-sm">
        <thead className="bg-slate-50/70">
          <tr className="text-left">
            <th className="p-2">Category</th>
            <th className="p-2">Total</th>
            <th className="p-2">Entries</th>
            <th className="p-2">Type</th>
            <th className="p-2 text-right">View</th>
          </tr>
        </thead>
        <tbody>
          {categoryRows.length===0 && (
            <tr><td className="p-4 text-slate-500" colSpan={5}>No entries this month.</td></tr>
          )}
          {categoryRows.map(name=>{
            const meta = catMetaMap.get(name) || { name, type:'Time', displayUnit:'Auto' };
            const totalDisplay = totalsByCategoryReadable[name]?.display || '—';
            const rows = entriesByCategory[name] || [];
            const isOpen = open===name;
            return (
              <React.Fragment key={name}>
                <tr className="border-b border-slate-100 hover:bg-slate-50/60 cursor-pointer" onClick={()=> setOpen(isOpen? null : name)}>
                  <td className="p-2 font-medium flex items-center gap-2">
                    {isOpen? <ChevronDown className="w-4 h-4"/> : <ChevronRight className="w-4 h-4"/>}
                    {name}
                  </td>
                  <td className="p-2">{totalDisplay}</td>
                  <td className="p-2">{rows.length}</td>
                  <td className="p-2">{meta.type}</td>
                  <td className="p-2 text-right text-slate-500">{isOpen? 'Hide' : 'Show'}</td>
                </tr>
                {isOpen && (
                  <tr className="bg-white/70">
                    <td className="p-0" colSpan={5}>
                      <div className="px-2 py-3">
                        <div className="overflow-auto rounded-xl border border-slate-200">
                          <table className="w-full text-xs">
                            <thead className="bg-slate-50/60">
                              <tr className="text-left">
                                <th className="p-2">Date</th>
                                <th className="p-2">Amount</th>
                                <th className="p-2">Notes</th>
                              </tr>
                            </thead>
                            <tbody>
                              {rows.slice().sort((a,b)=> a.date<b.date?1:-1).map(e=>{
                                const baseVal = entryBaseValue(e);
                                const display = formatForCategory(meta, baseVal);
                                return (
                                  <tr key={e.id} className="border-b border-slate-100">
                                    <td className="p-2 whitespace-nowrap">{e.date}</td>
                                    <td className="p-2">{display}</td>
                                    <td className="p-2 text-slate-600">{e.notes}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function EntryRow({ e, categories, converters, catTypeMap, unitsByType, updateEntry, removeEntry, editingId, setEditingId }){
  const isEditing = editingId===e.id; const [draft, setDraft] = useState(e);
  useEffect(()=> setDraft(e), [e]);
  const catType = catTypeMap.get(draft.category) || 'Time';
  const allowedUnits = unitsByType[catType] || converters.filter(c=>c.type===catType).map(c=>c.unit);
  useEffect(()=>{ if(!allowedUnits.includes(draft.unit)) setDraft(d=>({...d, unit: allowedUnits[0]})); }, [draft.category]);

  return (
    <tr className="border-b border-gray-100 hover:bg-gray-50/60">
      <td className="p-2 whitespace-nowrap">{isEditing? <input type="date" className="input" value={draft.date} onChange={ev=>setDraft({...draft, date: ev.target.value})}/> : <span className="font-medium">{e.date}</span>}</td>
      <td className="p-2">{isEditing? <select className="input" value={draft.category} onChange={ev=>setDraft({...draft, category: ev.target.value})}>{categories.map(c=> <option key={c.name}>{c.name}</option>)}</select> : e.category}</td>
      <td className="p-2 w-28">{isEditing? <input className="input" type="number" step="0.01" value={draft.value} onChange={ev=>setDraft({...draft, value: ev.target.value})}/> : <span>{e.value}</span>}</td>
      <td className="p-2">{isEditing? <select className="input" value={draft.unit} onChange={ev=>setDraft({...draft, unit: ev.target.value})}>{allowedUnits.map(u=> <option key={u}>{u}</option>)}</select> : e.unit}</td>
      <td className="p-2">{isEditing? <input className="input" value={draft.notes} onChange={ev=>setDraft({...draft, notes: ev.target.value})}/> : <span className="text-gray-600">{e.notes}</span>}</td>
      <td className="p-2 text-right">{isEditing? <div className="flex gap-2 justify-end"><button className="btn btn-primary" onClick={()=> (updateEntry(e.id, draft), setEditingId(null))}><Save className="w-4 h-4 mr-1"/>Save</button><button className="btn" onClick={()=> setEditingId(null)}><X className="w-4 h-4 mr-1"/>Cancel</button></div> : <div className="flex gap-2 justify-end"><button className="icon-btn" title="Edit" onClick={()=> setEditingId(e.id)}><Edit3 className="w-4 h-4"/></button><button className="icon-btn text-red-600" title="Delete" onClick={()=> removeEntry(e.id)}><Trash2 className="w-4 h-4"/></button></div>}</td>
    </tr>
  );
}

function CategoryManager({ categories, setCategories, onAdd, onSetType, onRemove, converters }){
  const [name, setName] = useState(""); const [type, setType] = useState('Time');
  return (
    <div>
      <div className="grid md:grid-cols-5 gap-2 mb-3">
        <input className="input" placeholder="Category name (e.g., Skip rope)" value={name} onChange={e=>setName(e.target.value)} />
        <select className="input" value={type} onChange={e=>setType(e.target.value)}>{TYPES.map(t=> <option key={t}>{t}</option>)}</select>
        <span className="text-sm self-center text-slate-500">Display as</span>
        <select className="input" disabled>
          <option>Auto</option>
        </select>
        <button className="btn btn-primary" onClick={()=> (onAdd(name, type), setName("") )}><PlusCircle className="w-4 h-4 mr-1"/>Add category</button>
      </div>
      <div className="overflow-auto rounded-2xl border border-slate-200">
        <table className="w-full text-sm">
          <thead className="bg-slate-50/70"><tr><th className="p-2 text-left">Name</th><th className="p-2 text-left">Type</th><th className="p-2 text-left">Display as</th><th className="p-2 text-right">Actions</th></tr></thead>
          <tbody>
            {categories.map(c=> (
              <tr key={c.name} className="border-b border-gray-100">
                <td className="p-2">{c.name}</td>
                <td className="p-2">
                  <select className="input" value={c.type} onChange={e=> onSetType(c.name, e.target.value)}>{TYPES.map(t=> <option key={t}>{t}</option>)}</select>
                </td>
                <td className="p-2">
                  <DisplayUnitSelect category={c} converters={converters} onChange={(u)=> setCategories(prev=> prev.map(x=> x.name===c.name? {...x, displayUnit:u}: x))} />
                </td>
                <td className="p-2 text-right"><button className="icon-btn text-red-600" onClick={()=> onRemove(c.name)}><Trash2 className="w-4 h-4"/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DisplayUnitSelect({ category, converters, onChange }){
  const units = useMemo(()=> converters.filter(c=> c.type===category.type).map(c=> c.unit), [converters, category.type]);
  const value = category.displayUnit || 'Auto';
  return (
    <select className="input" value={value} onChange={e=> onChange(e.target.value)}>
      <option>Auto</option>
      {units.map(u=> <option key={u} value={u}>{u}</option>)}
    </select>
  );
}

function ConverterManager({ converters, setConverters }){
  const [u,setU]=useState({ unit:"", type:"Time", baseUnit:"Hours", factorToBase:"" });
  const baseByType = { Time:["Hours"], Distance:["Km"], Count:["Times"], Volume:["Liters"] };
  function add(){ if(!u.unit||!u.type||!u.baseUnit||!u.factorToBase) return; if(converters.some(x=>x.unit===u.unit)) return alert('Unit exists'); setConverters(prev=>[...prev,{ unit:u.unit, type:u.type, baseUnit:u.baseUnit, factorToBase:Number(u.factorToBase)}]); setU({ unit:"", type:"Time", baseUnit:"Hours", factorToBase:""}); }
  function remove(unit){ setConverters(converters.filter(c=> c.unit!==unit)); }
  return (
    <div>
      <div className="grid md:grid-cols-4 gap-2 mb-3">
        <input className="input" placeholder="Unit (e.g., Minutes)" value={u.unit} onChange={e=>setU({...u, unit:e.target.value})} />
        <select className="input" value={u.type} onChange={e=> setU({...u, type:e.target.value, baseUnit: baseByType[e.target.value][0] })}>{TYPES.map(t=> <option key={t}>{t}</option>)}</select>
        <select className="input" value={u.baseUnit} onChange={e=> setU({...u, baseUnit:e.target.value})}>{(baseByType[u.type]||[]).map(b=> <option key={b}>{b}</option>)}</select>
        <input className="input" type="number" step="0.000001" placeholder="Factor → Base" value={u.factorToBase} onChange={e=> setU({...u, factorToBase:e.target.value})} />
      </div>
      <button className="btn btn-primary mb-4" onClick={add}><PlusCircle className="w-4 h-4 mr-1"/>Add unit</button>
      <div className="overflow-auto rounded-2xl border border-slate-200">
        <table className="w-full text-sm">
          <thead className="bg-slate-50/70"><tr><th className="p-2 text-left">Unit</th><th className="p-2 text-left">Type</th><th className="p-2 text-left">Base Unit</th><th className="p-2 text-right">Factor → Base</th><th className="p-2 text-right">Actions</th></tr></thead>
          <tbody>
            {converters.map(c=> (
              <tr key={c.unit} className="border-b border-gray-100">
                <td className="p-2">{c.unit}</td>
                <td className="p-2">{c.type}</td>
                <td className="p-2">{c.baseUnit}</td>
                <td className="p-2 text-right">{c.factorToBase}</td>
                <td className="p-2 text-right"><button className="icon-btn text-red-600" onClick={()=> remove(c.unit)}><Trash2 className="w-4 h-4"/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
