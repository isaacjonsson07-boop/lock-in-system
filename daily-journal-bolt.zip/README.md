# Daily Journal — Bolt-ready

This is a Vite + React project containing your Daily Journal app,
ready to import into **Bolt.new** (or run locally).

## Run locally

```bash
npm install
npm run dev
```

## Import into Bolt

1. Go to https://bolt.new
2. Start a new project and click **Upload files**. Drag-drop this zip.
3. Prompt Bolt: _“Install dependencies and run the Vite dev server. Configure Tailwind if needed.”_

You can also push this folder to GitHub and open it in Bolt by visiting:
`https://bolt.new/~/github.com/<your>/<repo>`
